// Importando o React
import React from "react";
// Importando os components necessários da lib react-materialize
import { Row, Col, Card } from 'react-materialize';

const Home = () => (
  <Row>
    <Col m={11} s={11}>
        <h5 className="subtitle">Sobre nós</h5>
        <Card>
          <div>
            <p><b>Trajetória</b></p>
            <p>Somos uma instituição de ensino brasileira, totalmente remota, com diversos cursos para auxiliar no aprendizado. Nosso principal objetivo é fazer com que o maior número de estudantes possível sinta-se preparado para prestar concursos.</p>
            <br/>
            <p><b>Objetivo</b></p>
            <p>Oferecer um ensino de qualidade para todos que busquem conhecimento, proporcionando melhores oportunidades para todos que busquem conhecimento.</p>
          </div>
        </Card>  
    </Col>
  </Row>
);

export default Home;