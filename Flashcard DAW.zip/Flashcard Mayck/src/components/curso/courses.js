// Importando o React
import React from "react";
// Importando os components necessários da lib react-materialize
import { Row } from 'react-materialize';

import { NavLink} from 'react-router-dom'

import Curso from "./course";


const Courses = (props) => {
  return (
    <div>
      <Row>
        <div class="row">
          <div class="rowc">
            <h5>Cursos</h5>
            {props.coursesData.map(course => (
              <Curso
                course={course} 
              />
            ))}
          </div>
          </div>
      </Row>
      <NavLink to="/form"><a class="btn-floating btn-large waves-effect waves-light red"><i class="material-icons">add</i></a></NavLink>
    </div>
  )
};

export default Courses;