import React from "react";
import Home from "./components/home/home";
import Contact from "./components/curso/courses";
import Form from './components/curso/form'
import Editar from './components/curso/editar'
import { Container } from 'react-materialize';
import { Routes, Route } from 'react-router-dom'

const Main = (props) => (
  <main>
    <Container>
      <Routes>
        <Route exact path='/' element={ <Home/> }/>
        <Route path='/courses' element={ <Contact coursesData={props.coursesData}/> }/>
        <Route path='/form' element={ <Form /> }/>
        <Route path='/form/editar/:colecaoId' element={ <Editar /> }/>
      </Routes>
    </Container>
  </main>  
);

export default Main;